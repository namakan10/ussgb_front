import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {Util_fonction} from '../../../shared/model/util_fonction';
import {EvenementsService} from '../../../shared/service/evenements.service';
import {Router} from '@angular/router';
import {_HTTP} from '../../../shared/model/CONSTANTES';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {StructuresService} from '../../../shared/service/structures.service';
import {element} from 'protractor';


@Component({
  selector: 'app-inscriptions-evenements',
  templateUrl: './inscriptions-evenements.component.html',
  styleUrls: ['./inscriptions-evenements.component.scss']
})
export class InscriptionsEvenementsComponent implements OnInit {
    _http = _HTTP;
    structureData : any;
    FilterForm: FormGroup;
  constructor(
      private evenementService: EvenementsService,
      private structuresService: StructuresService,
      private formBuilder: FormBuilder,
      private router: Router,
      private changeD: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
      this.initFilterForm();
      this.StructureData();
      if (Util_fonction.checkIfNoTEmpty(this.structureData.id)){
          setTimeout(()=> this.GetStructureEvenements(),800);
          setTimeout(()=> this.GetStuctureAnnees(),2000);
      } else {
          this.router.navigate(['']);
      }

  }

    /**
     * RECUPERE LES DONNEES DE LA STRUCTURE DANS LA SESSION
     * @constructor
     */
    StructureData(){
      this.structureData = JSON.parse(sessionStorage.getItem("structureData"));
    }

    StructureAnnees: any
    GetStuctureAnnees(){
        this.structuresService.getStuctureAnnees(this.structureData.id)
            .subscribe(res => {
                this.StructureAnnees = res;
                console.log(this.StructureAnnees );
                this.changeD.detectChanges();
            });
        this.changeD.detectChanges();
    }

    changeDetec(){
        this.changeD.detectChanges();
    }

    StructureEvenements:any;
    ListEvenements:any;
    GetStructureEvenements(){
        let typeEvent = ["CANDIDATURE", "INSCRIPTION", "RE_INSCRIPTION"];
        this.ListEvenements = [];
        const data = {
            type_evenement: null,
            id_annee: this.FilterForm.controls.anneeF.value,
            cursus: this.FilterForm.controls.cursus.value,
            id_structure: this.structureData.id
        }

        this.evenementService.getStucturesEvenements(data).subscribe(
            res => {
                this.StructureEvenements = res;
                if (Object.keys(res).length > 0){
                    for (let event of res){
                        if (Util_fonction.checkIfEventIsCurrent(event.dateDebut,event.dateFin) && typeEvent.includes(event.type)){
                            this.ListEvenements.push(event);
                        }
                    }
                }
                console.log(this.ListEvenements);
                if (Object.keys(this.ListEvenements).length <=0){
                    Util_fonction.AlertMessage('info', "Pas de résultat pour cette recherche !");
                }
            }, error => {
                Util_fonction.AlertMessage(error.error.status, error.error.message);
            }
        );
    }

    _Ans = '';
    _cursus = '';
    changeAns (event, selection) {
        if (selection === 'cursus'){
            this._cursus = event.target.options[event.target.options.selectedIndex].text;
        } else {
            this._Ans = event.target.options[event.target.options.selectedIndex].text;
        }
    }

    searchBol: boolean = false;
    filterSearch(){
        this.searchBol = true;


        this.GetStructureEvenements();

    }
   //
    GoToReInscriptionPage(evenement, newB){
        sessionStorage.setItem("evenementData", JSON.stringify(evenement));
        sessionStorage.setItem("newB", newB);
        this.router.navigate(['']);
    }

   //
    GoToProfilCheckingPage(evenement, newB){
        sessionStorage.setItem("evenementData", JSON.stringify(evenement));
        sessionStorage.setItem("newB", newB);
        this.router.navigate(['verification_et_profilage_du_candidat']);
    }

    checkIfIsNotEmpty(element){
        return Util_fonction.checkIfNoTEmpty(element)
    }

    initFilterForm() {
        this.FilterForm = this.formBuilder.group({
            anneeF: new FormControl(null, [Validators.required]),
            cursus: new FormControl(null)
        })
    }

}
