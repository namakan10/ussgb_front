import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InscriptionsEvenementsComponent } from './inscriptions-evenements.component';

describe('InscriptionsEvenementsComponent', () => {
  let component: InscriptionsEvenementsComponent;
  let fixture: ComponentFixture<InscriptionsEvenementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InscriptionsEvenementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InscriptionsEvenementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
