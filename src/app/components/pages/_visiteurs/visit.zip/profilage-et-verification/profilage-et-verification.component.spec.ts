import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilageEtVerificationComponent } from './profilage-et-verification.component';

describe('ProfilageEtVerificationComponent', () => {
  let component: ProfilageEtVerificationComponent;
  let fixture: ComponentFixture<ProfilageEtVerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilageEtVerificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilageEtVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
