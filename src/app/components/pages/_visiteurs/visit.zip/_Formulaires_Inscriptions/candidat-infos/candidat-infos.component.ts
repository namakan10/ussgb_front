import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {CandidatsService} from '../../../../shared/service/candidats.service';
import {PAYS_MONDE} from '../../../../shared/model/PAYS_MODE';
import {Util_fonction} from '../../../../shared/model/util_fonction';
import * as Util from 'util';

@Component({
  selector: 'app-candidat-infos',
  templateUrl: './candidat-infos.component.html',
  styleUrls: ['./candidat-infos.component.scss']
})
export class CandidatInfosComponent implements OnInit {
    @Output() candidatFormValid = new EventEmitter();
    candidatCandidatureInfoDatas ={ // candidature
        nom: "",
        prenom: "",
        dateDeNaissance: "",
        lieuDeNaissance: "",
        genre: "",
        paysDeNaissance: "",
        nationalite: "",
        ville: "",
        quartier: "",
        telephone: 0,
        email: "",
        telephoneTuteur: 0,
        modeAdmission: "",
        specialite: "",
        annee: ""
        // dateObtentionDiplome: "",
        // typeCandidat: "",
    }

    candidatPreInscriptionInfoDatas ={ // pré-inscription
        id: null,
        paysDeNaissance: "",
        nationalite: "",
        ville: "",
        quartier: "",
        rue: null,
        porte: null,
        telephone: 0,
        email: "",
        telephoneTuteur: 0,
        // annee: ""
        // genre: "",
        // modeAdmission: "",
        // dateObtentionDiplome: "",
        // specialite: "",
        // dateDeNaissance: "",
        // lieuDeNaissance: "",
        // typeCandidat: "",

    }
    candidatDataForm : FormGroup;


    Annees: any;
    Academies: any;
    CandidatSpecialites: any;
    modeAdmission: any;
    Pays = PAYS_MONDE;

    newB = sessionStorage.getItem('newB');
    candidatBDatas = JSON.parse(sessionStorage.getItem('candidatBDatas'));
  constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private candidatService: CandidatsService,
      // private CandidatSpecialites: S
  ) { }

  ngOnInit(): void {
      if (Util_fonction.checkIfNoTEmpty(sessionStorage.getItem('modeAdmission')) &&
          Util_fonction.checkIfNoTEmpty(this.newB)) {

          this.modeAdmission = sessionStorage.getItem('modeAdmission');
          this.getAcademie();
          this.getAllSepcialites();
          this.genereAnneeList();
          // this.candidatID = sessionStorage.getItem('id');
          // this.StructureSigle = sessionStorage.getItem('structureSigle');
          // this.logo_structure = sessionStorage.getItem('structureLogo');
          // this.limitAtion = sessionStorage.getItem('limit_postule');
          // this.StructureID = sessionStorage.getItem('id_structure');
          // this.candidatPreInscriptionInfoDatas.structure.id = this.StructureID;
          this.initForm();

      } else {
          this.backToStatutCheckingPage();
      }
  }

    // lISTE LES ANNEES DEPUI 1994
    genereAnneeList() {
        const Annees = [];
        let endAnnee: number = new Date().getFullYear();
        endAnnee = endAnnee - 1;
        for (let i = endAnnee; i > 1994; i--){
            Annees.push(i);
        }
        this.Annees = Annees;
    }

    // LISTE LES ACADEMIE DE DU BAC MALIEN
    getAcademie() {
        this.candidatService.getAcademies().subscribe(res => {
            this.Academies = res;
        });
    }

    getAllSepcialites() {
        this.candidatService.getSepcialites().subscribe(specialRes => {
            this.CandidatSpecialites = specialRes;
        });
    }

    /***
     * Remplissage auto du chant annee2 et annee
     */
    annee2: any;
    anneeScol: any;
    selectSecondYears(){
        this.candidatDataForm.controls.annee.setValue('');
        const annee1: number = (<number>this.candidatDataForm.controls.annee1.value);
        this.annee2 = Number(annee1);
        this.anneeScol = this.annee2 + ' - ';
        this.annee2 = this.annee2 + 1;
        this.anneeScol += this.annee2;
        this.candidatDataForm.controls.annee.setValue(this.anneeScol);

        this.checkAnneeDiplome(this.annee2);
    }

    /**
     *  Verification de l'année d'optention du diplôme.
     * @param annee2
     */
    checkAnneeDiplome(annee2: number) {
        const dateObtentionDiplomeDIp = this.candidatDataForm.controls.dateObtentionDiplome.value;
        const Year = new Date(dateObtentionDiplomeDIp).getFullYear();
        if (Year < annee2) {
            this.candidatDataForm.controls.annee.setValue(null);
            this.candidatDataForm.controls.annee1.setValue(null);
        }
    }

    /** ============ ===============
     *                  Save
     * ============= ===============
     */
    SavecandidatData(){

        // this.findSpecialiteID(this.candidatDataForm.controls.specialite.value);
        this.candidatDataForm.controls.annee.setValue(this.anneeScol);


        if (this.newB === 'oui'){

            // this.candidatPreInscriptionInfoDatas.annee = this.anneeScol;
            // this.candidatPreInscriptionInfoDatas.dateDeNaissance = this.candidatDataForm.controls.dateDeNaissance.value;
            // this.candidatPreInscriptionInfoDatas.lieuDeNaissance = this.candidatDataForm.controls.lieuDeNaissance.value;
            // this.candidatPreInscriptionInfoDatas.genre = this.candidatDataForm.controls.genre.value;

            this.candidatPreInscriptionInfoDatas.id = this.candidatBDatas.id;
            this.candidatPreInscriptionInfoDatas.email = this.candidatDataForm.controls.email.value;
            this.candidatPreInscriptionInfoDatas.paysDeNaissance = this.candidatDataForm.controls.paysDeNaissance.value;
            this.candidatPreInscriptionInfoDatas.nationalite = this.candidatDataForm.controls.nationalite.value;
            this.candidatPreInscriptionInfoDatas.ville = this.candidatDataForm.controls.ville.value;
            this.candidatPreInscriptionInfoDatas.quartier = this.candidatDataForm.controls.quartier.value;
            this.candidatPreInscriptionInfoDatas.rue = this.candidatDataForm.controls.rue.value;
            this.candidatPreInscriptionInfoDatas.porte = this.candidatDataForm.controls.porte.value;

            if (Util_fonction.checkIfNoTEmpty(this.candidatDataForm.controls.telephone.value)){
                this.candidatPreInscriptionInfoDatas.telephone = this.candidatDataForm.controls.telephone.value;
            }

            if (Util_fonction.checkIfNoTEmpty(this.candidatDataForm.controls.telephoneTuteur.value)){
                this.candidatPreInscriptionInfoDatas.telephoneTuteur = this.candidatDataForm.controls.telephoneTuteur.value;
            }

            sessionStorage.setItem("candidatDatas", JSON.stringify(this.candidatPreInscriptionInfoDatas));
        } else {

            this.candidatCandidatureInfoDatas.annee = this.anneeScol;
            this.candidatCandidatureInfoDatas.nom = this.candidatDataForm.controls.nom.value;
            this.candidatCandidatureInfoDatas.prenom = this.candidatDataForm.controls.prenom.value;
            this.candidatCandidatureInfoDatas.dateDeNaissance = this.candidatDataForm.controls.dateDeNaissance.value;
            this.candidatCandidatureInfoDatas.lieuDeNaissance = this.candidatDataForm.controls.lieuDeNaissance.value;
            this.candidatCandidatureInfoDatas.genre = this.candidatDataForm.controls.genre.value;

            this.candidatCandidatureInfoDatas.modeAdmission = this.candidatDataForm.controls.modeAdmission.value;
            this.candidatCandidatureInfoDatas.specialite = this.candidatDataForm.controls.specialite.value;

            this.candidatCandidatureInfoDatas.email = this.candidatDataForm.controls.email.value;
            this.candidatCandidatureInfoDatas.paysDeNaissance = this.candidatDataForm.controls.paysDeNaissance.value;
            this.candidatCandidatureInfoDatas.nationalite = this.candidatDataForm.controls.nationalite.value;
            this.candidatCandidatureInfoDatas.ville = this.candidatDataForm.controls.ville.value;
            this.candidatCandidatureInfoDatas.quartier = this.candidatDataForm.controls.quartier.value;

            if (Util_fonction.checkIfNoTEmpty(this.candidatDataForm.controls.telephone.value)){
                this.candidatCandidatureInfoDatas.telephone = this.candidatDataForm.controls.telephone.value;
            }

            if (Util_fonction.checkIfNoTEmpty(this.candidatDataForm.controls.telephoneTuteur.value)){
                this.candidatCandidatureInfoDatas.telephoneTuteur = this.candidatDataForm.controls.telephoneTuteur.value;
            }

            sessionStorage.setItem("candidatDatas", JSON.stringify(this.candidatCandidatureInfoDatas));

            // this.candidatFormIsValid.emit(true);
        }

        // this.router.navigate(['verification_et_profilage_du_candidat']);
    }



    // RETOUR AU VERIFICATION DE PROFILE
    backToStatutCheckingPage(){
      this.router.navigate(['verification_et_profilage_du_candidat']);
    }


    cadidatFormValidation(bol){
        if (bol){
            //invalid
            this.candidatFormValid.emit(true);
            sessionStorage.removeItem('candidatDatas');
        } else {
            //valid
            this.candidatFormValid.emit(false);
            this.SavecandidatData();
        }
    }

    /***
     * initialisation
     */
    initForm() {
        if (this.newB === 'oui'){
            this.candidatDataForm = this.formBuilder.group({
                annee1: new FormControl(null),
                annee2: new FormControl(null),

                nom: new FormControl(null),
                prenom: new FormControl(null),
                dateDeNaissance: new FormControl(null),
                lieuDeNaissance: new FormControl(null),
                genre: new FormControl(null),
                modeAdmission: new FormControl(sessionStorage.getItem('modeAdmission')),
                dateObtentionDiplome: new FormControl(null),

                specialite: new FormControl(null),
                // numMatricule: new FormControl(null),
                annee: new FormControl(null),

                email: new FormControl(null, [Validators.required,
                    Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]),

                paysDeNaissance: new FormControl(null, Validators.required),
                nationalite: new FormControl(null, Validators.required),
                ville: new FormControl(null, Validators.required),
                quartier: new FormControl(null, Validators.required),
                rue: new FormControl(null),
                porte: new FormControl(null),
                telephone: new FormControl(null, [Validators.minLength(8),
                    Validators.pattern('[0-9]*'), Validators.required]),

                telephoneTuteur: new FormControl(null),
            });
        } else {
            this.candidatDataForm = this.formBuilder.group({
                annee1: new FormControl(null, Validators.required),
                annee2: new FormControl(null),

                nom: new FormControl(null, Validators.required),
                prenom: new FormControl(null, Validators.required),
                dateDeNaissance: new FormControl(null, Validators.required),
                lieuDeNaissance: new FormControl(null, Validators.required),
                genre: new FormControl(null, Validators.required),
                modeAdmission: new FormControl(sessionStorage.getItem('modeAdmission')),
                dateObtentionDiplome: new FormControl(null, Validators.required), // ---new

                specialite: new FormControl(null, Validators.required),
                // numMatricule: new FormControl(null),
                annee: new FormControl(null, Validators.required),

                email: new FormControl(null, [Validators.required,
                    Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]),

                paysDeNaissance: new FormControl(null, Validators.required),
                nationalite: new FormControl(null, Validators.required),
                ville: new FormControl(null, Validators.required),
                quartier: new FormControl(null, Validators.required),
                rue: new FormControl(null),
                porte: new FormControl(null),
                telephone: new FormControl(null, [Validators.minLength(8),
                    Validators.pattern('[0-9]*'), Validators.required]),

                telephoneTuteur: new FormControl(null),
            });
        }
    }


}
