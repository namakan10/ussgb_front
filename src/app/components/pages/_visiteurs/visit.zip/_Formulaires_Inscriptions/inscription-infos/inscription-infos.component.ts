import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import {_HTTP, UNIV_FILIERE, UNIV_FILIERE_S, UNIV_OPTION, UNIV_OPTION_S} from '../../../../shared/model/CONSTANTES';

@Component({
  selector: 'app-inscription-infos',
  templateUrl: './inscription-infos.component.html',
  styleUrls: ['./inscription-infos.component.scss'],
    providers:[{
      provide: STEPPER_GLOBAL_OPTIONS,   useValue: {showError: true}
    }]
})
export class InscriptionInfosComponent implements OnInit {

    univ_fil = UNIV_FILIERE;
    univ_opt = UNIV_OPTION;
    _http = _HTTP;
    structureData = JSON.parse(sessionStorage.getItem('structureData'));
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    treeFormGroup: FormGroup;
    isLinear = true;
  constructor(
      private formBuilder: FormBuilder,
      private changeRef: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
      this.initForm();
      this.changeRef.detectChanges();
  }

    cadidatFormVText = "Veuilez Remplir tous les champs"
    CandidatFormValidation(event){
        console.log(event);
        if (event){
            this.cadidatFormVText = " Veuilez Remplir tous les champs ";
            this.firstFormGroup.controls.firstRequired.reset();
        } else {
            this.firstFormGroup.controls.firstRequired.reset('ok');
            this.cadidatFormVText ="Aller à l'etape suivante";
        }
    }

  initForm(){
      this.firstFormGroup = this.formBuilder.group({
          firstRequired: new FormControl(null, Validators.required)
      });
      this.secondFormGroup = this.formBuilder.group({
          secondRequired: new FormControl(null, Validators.required)
      });
      this.treeFormGroup = this.formBuilder.group({
          treeRequired: new FormControl(null, Validators.required)
      });
  }

}
