import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InscriptionInfosComponent } from './inscription-infos.component';

describe('InscriptionInfosComponent', () => {
  let component: InscriptionInfosComponent;
  let fixture: ComponentFixture<InscriptionInfosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InscriptionInfosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InscriptionInfosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
